package com.PearlThoughts.outpatient.entity;

import java.time.LocalDateTime;

public class Appointment {
	private int id;
    private int doctorId;
    private String patientName;
    private LocalDateTime appointmentTime;
    
	public Appointment(int id, int doctorId, String patientName, LocalDateTime appointmentTime) {
		super();
		this.id = id;
		this.doctorId = doctorId;
		this.patientName = patientName;
		this.appointmentTime = appointmentTime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public LocalDateTime getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(LocalDateTime appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	@Override
	public String toString() {
		return "Appointment [id=" + id + ", doctorId=" + doctorId + ", patientName=" + patientName
				+ ", appointmentTime=" + appointmentTime + "]";
	}
    
}
