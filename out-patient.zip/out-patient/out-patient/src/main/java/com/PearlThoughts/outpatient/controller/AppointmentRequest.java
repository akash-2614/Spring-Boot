package com.PearlThoughts.outpatient.controller;

public class AppointmentRequest {
    private int doctorId;
    private String patientName;

    
    public AppointmentRequest(int doctorId, String patientName) {
		super();
		this.doctorId = doctorId;
		this.patientName = patientName;
	}

	public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    
    
}

