package com.PearlThoughts.outpatient.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PearlThoughts.outpatient.entity.Appointment;
import com.PearlThoughts.outpatient.entity.Doctor;

import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping("/api")
public class DoctorController {
	int nextAppointmentId = 1;
    private List<Doctor> doctors = new ArrayList<>();
    private List<Appointment> appointments = new ArrayList<>();

    @PostConstruct
    private void init() {
        Doctor doctor1 = new Doctor(2014539,"Akash Rawat","Neurosurgeon",50);
        Doctor doctor2 = new Doctor(20,"Kirti Verma","cardiologist",60);
        
        doctors.add(doctor1);
        doctors.add(doctor2);
        
        LocalDateTime now = LocalDateTime.now();
        Appointment appointment1 = new Appointment(nextAppointmentId++, doctor1.getId(),"Roman Reigns", now.plusDays(1));
        Appointment appointment2 = new Appointment(nextAppointmentId++, doctor2.getId(),"Jon Snow", now.plusDays(1));
        
        appointments.add(appointment1);
        appointments.add(appointment2);
    }
    
    @GetMapping("/doctors")
    public List<Doctor> getDoctors() {
        return doctors;
    }

    @GetMapping("/doctors/{id}")
    public Doctor getDoctor(@PathVariable int id) {
        return doctors.stream()
                .filter(doctor -> doctor.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    @GetMapping("/appointments")
    public List<Appointment> getAppointments() {
        return appointments;
    }

/*    @PostMapping("/appointments")
    public void bookAppointment(@RequestBody AppointmentRequest appointmentRequest) {
    	Doctor doctor = getDoctor(appointmentRequest.getDoctorId());
        if (doctor != null) {
            Appointment appointment = new Appointment(nextAppointmentId++, appointmentRequest.getDoctorId(), appointmentRequest.getPatientName(), LocalDateTime.now());
            appointments.add(appointment);
        }
        
    } */
}
