package com.PearlThoughts.outpatient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutPatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
