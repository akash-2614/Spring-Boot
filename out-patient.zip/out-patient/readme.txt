Unzip the file.
Import the file in your IDE.
Run the application.
Open the browser and user the following links:
	http://localhost:8080/api/doctors - for all the information of the all the doctors.
	http://localhost:8080/api/doctors/{id} - for all the information of a specific Doctor
	http://localhost:8080/api/appointments - for all the appointments information

